# Am importat un produs de test prin Postman cu functioa POST
import sqlite3
from flask import Flask, request, jsonify

app = Flask(__name__)

conn = sqlite3.connect('catalog_produse.db')
cursor = conn.cursor()

conn.commit()
conn.close()

@app.route('/produse', methods=['POST'])
def adauga_produs():
    data = request.get_json()
    nume = data.get('nume')
    pret = data.get('pret')

    conn = sqlite3.connect('catalog_produse.db')
    cursor = conn.cursor()

    cursor.execute('INSERT INTO produse (nume, pret) VALUES (?, ?)', (nume, pret))
    conn.commit()
    conn.close()

    return jsonify({'mesaj': 'Produsul a fost adăugat cu succes!'}), 201

@app.route('/produse', methods=['GET'])
def lista_produse():
    conn = sqlite3.connect('catalog_produse.db')
    cursor = conn.cursor()

    cursor.execute('SELECT * FROM produse')
    produse = cursor.fetchall()

    conn.close()

    return jsonify(produse), 200

@app.route('/produse/<int:id>', methods=['PUT'])
def actualizeaza_produs(id):
    data = request.get_json()
    nume = data.get('nume')
    pret = data.get('pret')

    conn = sqlite3.connect('catalog_produse.db')
    cursor = conn.cursor()

    cursor.execute('UPDATE produse SET nume=?, pret=? WHERE id=?', (nume, pret, id))
    conn.commit()
    conn.close()

    return jsonify({'mesaj': 'Produsul a fost actualizat cu succes!'}), 200

@app.route('/produse/<int:id>', methods=['DELETE'])
def sterge_produs(id):
    conn = sqlite3.connect('catalog_produse.db')
    cursor = conn.cursor()

    cursor.execute('DELETE FROM produse WHERE id=?', (id,))
    conn.commit()
    conn.close()

    return jsonify({'mesaj': 'Produsul a fost șters cu succes!'}), 200

if __name__ == '__main__':
    app.run(debug=True)
