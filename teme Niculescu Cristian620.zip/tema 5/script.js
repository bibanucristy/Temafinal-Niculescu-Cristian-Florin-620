document.addEventListener('DOMContentLoaded', function() {
    const noteTitleInput = document.getElementById('note-title');
    const noteContentTextarea = document.getElementById('note-content');
    const saveNoteButton = document.getElementById('save-note');
    const deleteAllButton = document.getElementById('delete-all'); // Asigură-te că ai un buton cu acest ID în HTML
    const notesList = document.getElementById('notes-list');
    let editingNoteId = null; 

    function loadNotes() {
        fetch('/api/notes')
            .then(response => response.json())
            .then(notes => {
                notesList.innerHTML = '';
                notes.forEach(note => {
                    const listItem = document.createElement('li');
                    listItem.textContent = note.title + ' - ';
    
                    const editButton = document.createElement('button');
                    editButton.textContent = 'Vezi Notita / Editeaza';
                    editButton.onclick = function() { editNote(note.id); };
                    listItem.appendChild(editButton);
    
                    const deleteButton = document.createElement('button');
                    deleteButton.textContent = 'Sterge';
                    deleteButton.onclick = function() { deleteNote(note.id); };
                    listItem.appendChild(deleteButton);
    
                    const exportButton = document.createElement('button');
                    exportButton.textContent = 'Exporta PDF';
                    exportButton.onclick = function() { exportToPDF(note); };
                    listItem.appendChild(exportButton);
    
                    notesList.appendChild(listItem);
                });
            });
    }
    
    

    function editNote(id) {
        fetch(`/api/notes/${id}`)
            .then(response => response.json())
            .then(note => {
                noteTitleInput.value = note.title;
                noteContentTextarea.value = note.content;
                editingNoteId = id;
                saveNoteButton.textContent = 'Actualizează Notița';
            }).catch(error => console.error('Eroare la editarea notiței:', error));
    }

    function deleteNote(id) {
        fetch(`/api/notes/${id}`, { method: 'DELETE' })
            .then(() => loadNotes())
            .catch(error => console.error('Eroare la ștergerea notiței:', error));
    }

    saveNoteButton.addEventListener('click', function() {
        const title = noteTitleInput.value.trim();
        const content = noteContentTextarea.value.trim();
        const method = editingNoteId ? 'PUT' : 'POST';
        const endpoint = editingNoteId ? `/api/notes/${editingNoteId}` : '/api/notes';

        if (title && content) {
            fetch(endpoint, {
                method: method,
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ title, content })
            }).then(() => {
                loadNotes();
                noteTitleInput.value = '';
                noteContentTextarea.value = '';
                editingNoteId = null;
                saveNoteButton.textContent = 'Salveaza';
            }).catch(error => console.error('Eroare la salvarea notiței:', error));
        } else {
            alert('Te rog să completezi titlul și conținutul notiței.');
        }
    });

    deleteAllButton.addEventListener('click', function() {
        if (confirm('Ești sigur că vrei să ștergi toate notițele?')) {
            fetch('/api/notes', { method: 'DELETE' })
                .then(() => loadNotes())
                .catch(error => console.error('Eroare la ștergerea tuturor notițelor:', error));
        }
    });

    loadNotes();
});
document.getElementById('export-pdf').addEventListener('click', function() {
    const noteTitle = noteTitleInput.value;
    const noteContent = noteContentTextarea.value;

    // Crearea unei instanțe jsPDF
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    // Adăugarea titlului și a conținutului în document
    doc.text(noteTitle, 10, 10);
    doc.text(noteContent, 10, 20);

    // Salvarea documentului
    doc.save('notita.pdf');
});

function exportToPDF(note) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    doc.text(note.title, 10, 10);
    doc.text(note.content, 10, 20);

    doc.save(note.title + '.pdf');
}
