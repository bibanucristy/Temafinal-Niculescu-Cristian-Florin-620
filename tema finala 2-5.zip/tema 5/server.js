const express = require('express');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();

const app = express();
const db = new sqlite3.Database('bd_notite.db');

app.use(bodyParser.json());
app.use(express.static('.')); 

// get all notes
app.get('/api/notes', (req, res) => {
    db.all('SELECT * FROM notite', [], (err, rows) => {
        if (err) {
            console.error("Eroare la SELECT în notite:", err.message);
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(rows);
    });
});

app.get('/api/notes/:id', (req, res) => {
    const { id } = req.params;
    db.get('SELECT * FROM notite WHERE id = ?', [id], (err, row) => {
        if (err) {
            console.error("Eroare la SELECT o notiță în notite:", err.message);
            res.status(500).json({ error: err.message });
            return;
        }
        if (row) {
            res.json(row);
        } else {
            res.status(404).json({ error: 'Notița nu a fost găsită.' });
        }
    });
});

app.post('/api/notes', (req, res) => {
    const { title, content } = req.body;
    db.run('INSERT INTO notite (title, content) VALUES (?, ?)', [title, content], function(err) {
        if (err) {
            console.error("Eroare la INSERT în notite:", err.message);
            res.status(500).json({ error: err.message });
            return;
        }
        res.status(201).json({ id: this.lastID });
    });
});

app.put('/api/notes/:id', (req, res) => {
    const { id } = req.params;
    const { title, content } = req.body;
    db.run('UPDATE notite SET title = ?, content = ? WHERE id = ?', [title, content, id], function(err) {
        if (err) {
            console.error("Eroare la UPDATE în notite:", err.message);
            res.status(500).json({ error: err.message });
            return;
        }
        res.status(200).json({ message: 'Note updated' });
    });
});

app.delete('/api/notes/:id', (req, res) => {
    const { id } = req.params;
    db.run('DELETE FROM notite WHERE id = ?', id, function(err) {
        if (err) {
            console.error("Eroare la DELETE în notite:", err.message);
            res.status(500).json({ error: err.message });
            return;
        }
        res.status(200).json({ message: 'Note deleted' });
    });
});

app.delete('/api/notes', (req, res) => {
    db.run('DELETE FROM notite', function(err) {
        if (err) {
            console.error("Eroare la ștergerea tuturor notițelor:", err.message);
            res.status(500).json({ error: err.message });
            return;
        }
        res.status(200).json({ message: 'All notes deleted' });
    });
});

app.listen(3000, () => {
    console.log('Server is running on port 3000');
});
